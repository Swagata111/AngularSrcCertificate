import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { CertificatePojo } from '../certificatepojo';
import { RegisterService } from '../register.service';
import { voucher } from '../voucher';

@Component({
  selector: 'app-table-list',
  templateUrl: './table-list.component.html',
  styleUrls: ['./table-list.component.css']
})
export class TableListComponent implements OnInit {
  model: voucher[];
  displayedColumns: string[] = ['vouch-code','stream','examName', 'status', 'empId','empName', 'action'];
  dataSource = new MatTableDataSource();
  searchKey:string;
  emp:CertificatePojo;
  empName:string;
  cerName:string[];
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {
      
    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {
    this.res.getAllVoucherDetails().subscribe(res=>
    {
      this.dataSource.data=res;

    });
  }

}

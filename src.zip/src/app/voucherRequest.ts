export class VoucherRequest{
    empId:string;
    empName:string;
    emailId:string;
    stream:string;
    examName:string;
    voucherReqDate:string;
    
}
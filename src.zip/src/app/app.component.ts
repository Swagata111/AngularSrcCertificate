import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  role="";
  title = 'certificate';
  login(){
    console.log("login");
    sessionStorage.setItem('islogins',"false");
    return sessionStorage.getItem('islogins');
  }
}


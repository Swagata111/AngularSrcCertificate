import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCertComponent } from './admin-cert.component';

describe('AdminCertComponent', () => {
  let component: AdminCertComponent;
  let fixture: ComponentFixture<AdminCertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

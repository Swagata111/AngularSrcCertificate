import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-cert',
  templateUrl: './admin-cert.component.html',
  styleUrls: ['./admin-cert.component.css']
})
export class AdminCertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

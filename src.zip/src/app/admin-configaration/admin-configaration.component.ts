import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatIconRegistry, MatDialogConfig, MatDialog } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { AdminAddCorecertComponent } from '../admin-add-corecert/admin-add-corecert.component';

@Component({
  selector: 'app-admin-configaration',
  templateUrl: './admin-configaration.component.html',
  styleUrls: ['./admin-configaration.component.css']
})
export class AdminConfigarationComponent implements OnInit {

  displayedColumns: string[] = ['certificationCategory', 'certificationName','activeStatus', 'coreCeritification','level', 'voucherAvailable'];
  dataSource = new MatTableDataSource();
  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }
    
  ngOnInit(){
    this.res.getCoreCer().subscribe(res=>
      {
        this.dataSource.data=res;
      });
  }
  oncreate(){
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(AdminAddCorecertComponent,dialogconfig); 
  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
}


import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddExamScoresComponent } from './add-exam-scores.component';

describe('AddExamScoresComponent', () => {
  let component: AddExamScoresComponent;
  let fixture: ComponentFixture<AddExamScoresComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddExamScoresComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddExamScoresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

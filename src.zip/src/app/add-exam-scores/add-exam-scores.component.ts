import { Component, OnInit } from '@angular/core';
import { Scores } from '../scores';
import { FormBuilder } from '@angular/forms';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { MatIconRegistry } from '@angular/material';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import {MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-add-exam-scores',
  templateUrl: './add-exam-scores.component.html',
  styleUrls: ['./add-exam-scores.component.css']
})
export class AddExamScoresComponent implements OnInit {

  model:Scores=new Scores();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<AddExamScoresComponent>,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }


  ngOnInit() {
  }
  onclose(){
    this.dialogref.close();
  }
}

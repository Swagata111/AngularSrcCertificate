import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry, MatTableDataSource } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { Tower } from '../tower';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  displayedColumns: string[] = ['tower', 'totalEmployee', 'totalCertified','coreCertified', 'certificationPercent','corePercentage'];
  // displayedColumns1: string[] = ['stream', 'certificationName', 'totalVouchers', 'used','blocked','remaining'];
  model: Tower[];

  dataSource = new MatTableDataSource();
  vouchers = new MatTableDataSource();

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        
      }
    
  ngOnInit(){

    this.res.getCertificateTotal().subscribe(res=>
      {
        this.dataSource.data=res;

      });
      // this.res.getVoucherTotal().subscribe(res=>
      //   {
      //     this.vouchers.data=res;
      //   });
  
  }

  

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
}
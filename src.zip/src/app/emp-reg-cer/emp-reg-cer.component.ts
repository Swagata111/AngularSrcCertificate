import { Component, OnInit } from '@angular/core';
import { CoreCertificatePojo } from '../corecertificatepojo';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegisterService } from '../register.service';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { PlannedCertification } from '../plannedcertification';
import { tick } from '@angular/core/testing';

@Component({
  selector: 'app-emp-reg-cer',
  templateUrl: './emp-reg-cer.component.html',
  styleUrls: ['./emp-reg-cer.component.css']
})
export class EmpRegCerComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  cerCat:string[];

  cerName:string[];
  
  model:PlannedCertification=new PlannedCertification();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {

    this.log.getCertificationCategory().subscribe(data=>{
      this.cerCat = data as string[];
      console.log(this.cerCat);
    });

    this.regForm = this.fb.group({

      Stream: ['', [Validators.required ]],
  
      examName: ['',[ Validators.required] ],
      
      expectedDate: ['',[Validators.required]],

    });
  }
  reg(){
    this.submitted = true;
    this.model=new PlannedCertification();

  }
  check=false;
  onAdd(){
    this.submitted=true;
    this.check=true;
    const obj={
      empId:localStorage.getItem('empId'),
      empName:localStorage.getItem('empName'),
      Stream:this.model.Stream,
      examName:this.model.examName,
      expectedDate:this.model.expectedDate

    }
    console.log(this.model.examName);
    this.log.registerCertificate(obj)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)        
            location.href='http://localhost:4200/cerprog';
      });


  }
  onCategory(cerCategory)
  {
    console.log(cerCategory);
    this.log.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
      console.log(this.cerName);
    });;

  }
  
}


import { Component, OnInit } from '@angular/core';
import { Tower } from '../tower';
import { MatTableDataSource, MatIconRegistry, MatDialog, MatDialogConfig } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { PlannedCertification } from '../plannedcertification';
import { EditPlannedCertificationComponent } from '../edit-planned-certification/edit-planned-certification.component';

@Component({
  selector: 'app-certification-progress',
  templateUrl: './certification-progress.component.html',
  styleUrls: ['./certification-progress.component.css']
})
export class CertificationProgressComponent implements OnInit {

  displayedColumns: string[] = ['Stream', 'examName', 'expectedDate','voucherStatus','regDate','voucherCode','voucherReqDate','voucherAssignedDate','examDate','result','score','comments','edit','viewprogress'];
  model: PlannedCertification[];

  dataSource = new MatTableDataSource();

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        
      }
    
  ngOnInit(){

    this.res.getPlannedCertificate().subscribe(res=>
      {
        console.log(res);
        this.dataSource.data=res;

      });
  
  }

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }

  applyFilter() 
  {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  onEdit(element)
  {
    this.res.storeplanned(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(EditPlannedCertificationComponent,dialogconfig); 
  }
}
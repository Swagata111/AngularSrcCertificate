export class PlannedCertification{
	
    Stream: string;
	examName:string;
    expectedDate:string;
    testMarks:number;
    empId:string;
    empName:string;
	_id: string;
	voucherStatus: string;
	regDate: string;
	voucherCode: string;
    voucherReqDate: string;
	voucherAssignedDate: string;
	examDate: string;
	result: string;
	score: number;
	comments: string; 

}
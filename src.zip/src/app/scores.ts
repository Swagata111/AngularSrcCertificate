export class Scores
{
    score:number[];
}
export class AdminVoucherPojo{

        stream:string;

        certificationName:string;
        
        blockedCount: number;

        utilizedCount:number;
        
        totalVouchers:number;

        expiredCount:number;
        
        availableCount:number;

}
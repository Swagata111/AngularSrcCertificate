import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, share } from 'rxjs/operators';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-side',
  templateUrl: './side.component.html',
  styleUrls: ['./side.component.css']
})
export class SideComponent  {
  count=0;
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      share()
    );
  constructor(private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private log:RegisterService,
    private route:Router) {
    iconRegistry.addSvgIcon(
        'menu',
        sanitizer.bypassSecurityTrustResourceUrl('assets/menu.svg'));
      
      iconRegistry.addSvgIcon(
        'account',
        sanitizer.bypassSecurityTrustResourceUrl('assets/account.svg'));
      }
      read(){
        return localStorage.getItem('role ');
      }
      logout(){
        sessionStorage.setItem('islogins',"false");
        //localStorage.setItem('username',' ');
        localStorage.removeItem('role');
       // this.authservice.logout();
       this.route.navigateByUrl('login');
      }
      readvalue(){
        //console.log(sessionStorage.getItem('islogins'))
        console.log("entered");
        if(this.count=0){
          this.count=this.count+1;
          console.log("login");
          return this.log.login();
        }
        else{
          return sessionStorage.getItem('islogins');
        }
      }
}

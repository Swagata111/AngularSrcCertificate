export class CoreCertificatePojo{
    certificationCategory: string;
	certificationName: string;
	activeStatus: string;
    coreCeritification: string;
	level: string;
	voucherAvailable: string;
}
export class Tower{
    towerName:string;
    totalEmp:number;
    certifiedEmp:number;
    coreCertified:number;
    nonCoreCertified:number;
    corePercentage:number;
    percentage:number;
}
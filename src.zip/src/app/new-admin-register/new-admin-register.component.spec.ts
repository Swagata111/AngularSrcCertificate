import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewAdminRegisterComponent } from './new-admin-register.component';

describe('NewAdminRegisterComponent', () => {
  let component: NewAdminRegisterComponent;
  let fixture: ComponentFixture<NewAdminRegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewAdminRegisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewAdminRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

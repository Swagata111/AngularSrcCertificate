export class AdminLogPojo{
    empId:number;
    name:string;
    password:string;
    confirmpassword:string;
}
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { RegisterPojo } from '../registerpojo';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private islogin:boolean=false;
  constructor(private fb: FormBuilder, private route: Router, private userService:RegisterService) { }
  regForm: FormGroup;
  submitted: boolean = false;
  response: any;
  employee:RegisterPojo=new RegisterPojo();

  ngOnInit() {
    
    this.regForm = this.fb.group({
      empId: ['', [Validators.required ]],
      password:['',[ Validators.required] ],
    });
   
  }
  login(){
    this.submitted=false;

    this.employee=new RegisterPojo();
  }
   check=true;
   eid;
   ename;
  onLogin(){
   this.submitted=true;
   console.log(this.employee.empId)
     this.userService.validateEmployee(this.employee)
      .subscribe((data) =>{
        
            (console.log(data),error=>console.error(error));
            if(data!=null){
              this.check=true;
              sessionStorage.setItem('islogins',"true");
              localStorage.setItem('role',"emp");
              this.eid=this.employee.empId;
              this.ename=data.empName;
              localStorage.setItem('empId',this.eid);
              localStorage.setItem('empName',this.ename);
              console.log(localStorage.getItem('empId'));
              location.href="http://localhost:4200/alreadycert";
              //this.route.navigateByUrl('alreadycert');
            }
            else{
               this.check=false;
              this.route.navigateByUrl('login');
             }
            this.employee=new RegisterPojo();
      })
   }
   read(key){
     return localStorage.getItem('admin');
   }
 
}
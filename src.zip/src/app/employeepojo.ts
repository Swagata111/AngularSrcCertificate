export class EmployeePojo{
    empId: string;
	empName: string;
	localGrade: string;
	mode: string;
	empStatus: string;
	cloudDoj: string;
	joiningDate: string;
    location: string;
	email: string;
	globalPractice: string;
	resignedLwd: string;
	loanedOut: string;
	billability: string;
	primarySkill: string;
	skillDashboarding: string;
}